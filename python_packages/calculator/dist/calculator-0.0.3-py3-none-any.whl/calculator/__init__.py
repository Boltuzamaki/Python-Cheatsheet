class Calculator:
    def __init__(self):
        print("constructer")

    def addition(self, num1, num2):
        return num1 + num2

    def subtraction(self, num1, num2):
        return num1 - num2

    def multiplication(self, num1, num2):
        return num1*num2

    def division(self, num1, num2):
        return num1/num2
