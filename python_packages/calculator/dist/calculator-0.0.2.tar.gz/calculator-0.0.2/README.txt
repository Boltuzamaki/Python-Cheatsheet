This is a calculator which helps to addition, subtraction, multiplication and division. :)
